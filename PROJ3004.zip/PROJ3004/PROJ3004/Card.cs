﻿using System;

namespace PROJ3004
{
	abstract public class Card
	{
		abstract public override string ToString ();

	}
}

