﻿using System;

namespace PROJ3004
{
	abstract public class Story : Card
	{
		protected string name;

		public string GetName(){
			return name;
		}
			
	}
}

