package sample;

abstract public class Story extends Card {
    protected String name;

    public String GetName(){
        return name;
    }
}