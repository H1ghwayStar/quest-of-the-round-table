package sample;

abstract public class Card
{
    @Override
    abstract public String toString ();

}
